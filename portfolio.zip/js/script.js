// Navigation Menu Toggle
const navSlide = () => {
    const burger = document.querySelector('.burger');
    const nav = document.querySelector('.nav-links');
    const navLinks = document.querySelectorAll('.nav-links li');
    
    burger.addEventListener('click', () => {
        // Toggle Nav
        nav.classList.toggle('nav-active');
        
        // Animate Links
        navLinks.forEach((link, index) => {
            if (link.style.animation) {
                link.style.animation = '';
            } else {
                link.style.animation = `navLinkFade 0.5s ease forwards ${index / 7 + 0.3}s`;
            }
        });
        
        // Burger Animation
        burger.classList.toggle('toggle');
    });
}

// Project Modal
const projectModal = () => {
    const modal = document.getElementById('projectModal');
    const modalBody = document.querySelector('.modal-body');
    const closeBtn = document.querySelector('.close-modal');
    const projectBtns = document.querySelectorAll('.project-details');
    
    // Project Details Content
    const projectDetails = {
        sinori: {
            title: 'SINORI - Sistem Penomoran Surat Keluar',
            description: `
                <p>SINORI adalah sistem informasi yang dirancang untuk mengotomatisasi dan mengelola penomoran surat keluar di Rumah Tahanan Negara (Rutan) Pelaihari. Sistem ini membantu meningkatkan efisiensi administrasi dan memastikan pengelolaan dokumen yang lebih terstruktur.</p>
                
                <h4>Tantangan</h4>
                <p>Tantangan utama dalam pengembangan SINORI adalah memastikan keamanan data dan kemudahan penggunaan bagi staf yang memiliki tingkat literasi digital yang beragam. Selain itu, sistem harus dapat mengotomatisasi penomoran surat dengan format yang konsisten dan mencegah duplikasi nomor surat.</p>
                
                <h4>Solusi</h4>
                <ul>
                    <li>Mengimplementasikan sistem autentikasi berbasis NIP dengan validasi yang ketat</li>
                    <li>Merancang antarmuka yang intuitif dengan panduan kontekstual</li>
                    <li>Mengembangkan algoritma penomoran otomatis dengan validasi duplikasi</li>
                    <li>Menerapkan sistem pencarian dan filter untuk memudahkan pencarian surat</li>
                    <li>Membuat dashboard untuk monitoring dan statistik</li>
                </ul>
                
                <h4>Teknologi yang Digunakan</h4>
                <ul>
                    <li>PHP 7.4 untuk back-end</li>
                    <li>MySQL untuk database</li>
                    <li>HTML5/CSS3 untuk front-end</li>
                    <li>JavaScript untuk interaktivitas</li>
                    <li>Bootstrap 4 untuk desain responsif</li>
                    <li>AJAX untuk pengalaman pengguna yang dinamis</li>
                </ul>
                
                <h4>Hasil</h4>
                <p>SINORI berhasil mengotomatisasi proses penomoran surat keluar, mengurangi kesalahan manusia, dan meningkatkan efisiensi administrasi di Rutan Pelaihari. Sistem ini juga memudahkan pencarian dan pelacakan surat, serta memberikan data statistik yang bermanfaat untuk evaluasi dan pelaporan.</p>
            `
        },
        ecatalog: {
            title: 'E-Catalog Rutan Pelaihari',
            description: `
                <p>E-Catalog adalah platform e-commerce yang dirancang untuk memperkenalkan dan memasarkan hasil karya dan produk pertanian dari warga binaan Rutan Pelaihari. Platform ini membantu meningkatkan visibilitas produk dan mendukung program pembinaan kemandirian.</p>
                
                <h4>Tantangan</h4>
                <p>Tantangan dalam pengembangan E-Catalog adalah menciptakan tampilan yang menarik untuk menonjolkan produk dengan tetap mempertahankan performa yang baik. Selain itu, sistem harus mudah dikelola oleh staf dengan berbagai tingkat kemampuan teknis.</p>
                
                <h4>Solusi</h4>
                <ul>
                    <li>Merancang antarmuka yang bersih dan fokus pada visual produk</li>
                    <li>Mengoptimalkan gambar produk untuk kecepatan loading</li>
                    <li>Menerapkan lazy loading untuk meningkatkan performa</li>
                    <li>Membuat sistem kategorisasi produk yang intuitif</li>
                    <li>Mengembangkan panel admin yang mudah digunakan untuk pengelolaan produk</li>
                </ul>
                
                <h4>Teknologi yang Digunakan</h4>
                <ul>
                    <li>PHP untuk back-end</li>
                    <li>MySQL untuk database katalog produk</li>
                    <li>HTML5/CSS3 untuk front-end</li>
                    <li>JavaScript untuk interaktivitas</li>
                    <li>Framework CSS untuk desain responsif</li>
                    <li>Optimasi gambar untuk performa web</li>
                </ul>
                
                <h4>Hasil</h4>
                <p>E-Catalog berhasil meningkatkan visibilitas produk hasil karya warga binaan Rutan Pelaihari. Platform ini memudahkan masyarakat untuk melihat dan memesan produk, serta mendukung program pembinaan kemandirian dengan memberikan wadah pemasaran yang lebih luas.</p>
            `
        },
        esop: {
            title: 'E-SOP Rutan Pelaihari',
            description: `
                <p>E-SOP adalah Sistem Informasi Standar Operasional Prosedur yang dirancang untuk meningkatkan efisiensi dan transparansi dalam pelaksanaan prosedur kerja di Rutan Pelaihari. Sistem ini memudahkan akses dan pemahaman terhadap SOP yang berlaku.</p>
                
                <h4>Tantangan</h4>
                <p>Tantangan dalam pengembangan E-SOP adalah mengorganisir informasi yang kompleks menjadi format yang mudah diakses dan dipahami. SOP sering kali berupa dokumen panjang dengan alur prosedur yang rumit, sehingga perlu disajikan dengan cara yang lebih user-friendly.</p>
                
                <h4>Solusi</h4>
                <ul>
                    <li>Menerapkan sistem kategorisasi yang jelas berdasarkan departemen/fungsi</li>
                    <li>Mengembangkan fitur pencarian yang powerful dengan filter multi-kriteria</li>
                    <li>Membuat visualisasi alur prosedur untuk mempermudah pemahaman</li>
                    <li>Menyediakan opsi download dokumen dalam format PDF</li>
                    <li>Mengintegrasikan dengan aplikasi lain seperti SINORI dan SIMANTROLING</li>
                </ul>
                
                <h4>Teknologi yang Digunakan</h4>
                <ul>
                    <li>PHP untuk back-end</li>
                    <li>MySQL untuk penyimpanan SOP</li>
                    <li>HTML5/CSS3 untuk front-end</li>
                    <li>JavaScript untuk interaktivitas</li>
                    <li>AJAX untuk pengalaman pengguna yang dinamis</li>
                    <li>FPDF untuk generasi dokumen PDF</li>
                </ul>
                
                <h4>Hasil</h4>
                <p>E-SOP berhasil meningkatkan aksesibilitas dan pemahaman terhadap Standar Operasional Prosedur di Rutan Pelaihari. Sistem ini memudahkan staf untuk menemukan dan memahami prosedur yang relevan dengan tugas mereka, serta memastikan kepatuhan terhadap standar yang ditetapkan.</p>
            `
        },
        pojokpengaduan: {
            title: 'Pojok Pengaduan Rutan Pelaihari',
            description: `
                <p>Pojok Pengaduan adalah platform pengaduan online yang dirancang untuk menyampaikan keluhan dan saran terkait pelayanan Rutan Pelaihari. Platform ini membantu meningkatkan transparansi dan responsivitas terhadap masukan dari masyarakat.</p>
                
                <h4>Tantangan</h4>
                <p>Tantangan dalam pengembangan Pojok Pengaduan adalah memastikan keamanan data pelapor dan efisiensi penanganan pengaduan. Sistem harus menjamin kerahasiaan identitas pelapor saat diperlukan, sekaligus memungkinkan pelacakan status pengaduan secara transparan.</p>
                
                <h4>Solusi</h4>
                <ul>
                    <li>Menerapkan enkripsi data sensitif untuk melindungi identitas pelapor</li>
                    <li>Mengembangkan sistem tracking yang memungkinkan pemantauan status pengaduan</li>
                    <li>Membuat alur kerja yang terstruktur untuk penanganan pengaduan</li>
                    <li>Menyediakan fitur upload file pendukung untuk pengaduan</li>
                    <li>Mengimplementasikan notifikasi email untuk update informasi</li>
                </ul>
                
                <h4>Teknologi yang Digunakan</h4>
                <ul>
                    <li>PHP untuk back-end</li>
                    <li>MySQL untuk database pengaduan</li>
                    <li>HTML5/CSS3 untuk front-end</li>
                    <li>JavaScript untuk interaktivitas dan validasi form</li>
                    <li>AJAX untuk tracking realtime</li>
                    <li>PHPMailer untuk notifikasi email</li>
                </ul>
                
                <h4>Hasil</h4>
                <p>Pojok Pengaduan berhasil meningkatkan transparansi dan responsivitas Rutan Pelaihari terhadap masukan dari masyarakat. Platform ini memudahkan proses penyampaian dan penanganan pengaduan, serta memberikan jaminan bahwa setiap pengaduan akan ditindaklanjuti dengan serius.</p>
            `
        }
    };
    
    // Open Modal with Project Details
    projectBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const project = btn.getAttribute('data-project');
            modalBody.innerHTML = `
                <h2>${projectDetails[project].title}</h2>
                <div class="modal-content-body">
                    ${projectDetails[project].description}
                </div>
            `;
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        });
    });
    
    // Close Modal
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    });
    
    // Close Modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target == modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });
}

// Form Validation
const formValidation = () => {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Basic validation
            let valid = true;
            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const subject = document.getElementById('subject');
            const message = document.getElementById('message');
            
            if (name.value.trim() === '') {
                valid = false;
                showError(name, 'Nama tidak boleh kosong');
            } else {
                removeError(name);
            }
            
            if (email.value.trim() === '') {
                valid = false;
                showError(email, 'Email tidak boleh kosong');
            } else if (!isValidEmail(email.value)) {
                valid = false;
                showError(email, 'Format email tidak valid');
            } else {
                removeError(email);
            }
            
            if (subject.value.trim() === '') {
                valid = false;
                showError(subject, 'Subjek tidak boleh kosong');
            } else {
                removeError(subject);
            }
            
            if (message.value.trim() === '') {
                valid = false;
                showError(message, 'Pesan tidak boleh kosong');
            } else {
                removeError(message);
            }
            
            if (valid) {
                // In a real application, this would send the form data to a server
                alert('Pesan Anda telah terkirim! Terima kasih telah menghubungi saya.');
                contactForm.reset();
            }
        });
    }
}

// Helper function to show error
const showError = (input, message) => {
    const formGroup = input.parentElement;
    const errorElement = document.createElement('small');
    errorElement.className = 'error-message';
    errorElement.style.color = 'red';
    errorElement.style.display = 'block';
    errorElement.style.marginTop = '5px';
    errorElement.innerText = message;
    
    // Remove any existing error message
    const existingError = formGroup.querySelector('.error-message');
    if (existingError) {
        formGroup.removeChild(existingError);
    }
    
    formGroup.appendChild(errorElement);
    input.style.borderColor = 'red';
}

// Helper function to remove error
const removeError = (input) => {
    const formGroup = input.parentElement;
    const existingError = formGroup.querySelector('.error-message');
    if (existingError) {
        formGroup.removeChild(existingError);
    }
    input.style.borderColor = '';
}

// Helper function to validate email
const isValidEmail = (email) => {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

// Smooth Scrolling for Navigation Links
const smoothScroll = () => {
    const navLinks = document.querySelectorAll('.nav-links a, .footer-links a, .hero-buttons a');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            if (link.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                
                const targetId = link.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                
                if (targetElement) {
                    // Close mobile menu if open
                    const nav = document.querySelector('.nav-links');
                    if (nav.classList.contains('nav-active')) {
                        document.querySelector('.burger').click();
                    }
                    
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

// Initialize all functions
document.addEventListener('DOMContentLoaded', () => {
    navSlide();
    projectModal();
    formValidation();
    smoothScroll();
});
